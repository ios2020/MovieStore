//
//  SegueIdentifers.swift
//  MovieStore
//
//  Created by Brahmastra on 17/01/20.
//  Copyright © 2020 Brahmastra. All rights reserved.
//

import Foundation

class SegueIdenfier {
    
 static let idenfier = SegueIdenfier()
    let nowPlayScreen = "DL102ForNowPlaying"
    let upcomingScreen = "DL102ForUpcoming"
    let topRateScreen = "DL102ForToprated"
    
    
    
}
