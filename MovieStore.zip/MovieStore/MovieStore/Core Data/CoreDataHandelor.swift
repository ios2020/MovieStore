//
//  File.swift
//  MovieStore
//
//  Created by Brahmastra on 14/01/20.
//  Copyright © 2020 Brahmastra. All rights reserved.
//

import Foundation
import CoreData

class CoreDataHandelor {
    var movie = [MovieInfo]()
    static let coreDataCaller = CoreDataHandelor()
    
    func saveData(object: [String:String])
    {
        
        
    }
}
