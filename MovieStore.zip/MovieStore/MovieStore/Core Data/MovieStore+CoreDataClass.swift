//
//  MovieStore+CoreDataClass.swift
//  
//
//  Created by Brahmastra on 14/01/20.
//
//

import Foundation
import CoreData

@objc(MovieStore)
public class MovieStore: NSManagedObject {

}
