//
//  NowPlayHeaderCell.swift
//  MovieStore
//
//  Created by Brahmastra on 13/01/20.
//  Copyright © 2020 Brahmastra. All rights reserved.
//

import UIKit



class NowPlayHeaderCell: UICollectionReusableView {
    
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var userImg: UIImageView!
    
}
