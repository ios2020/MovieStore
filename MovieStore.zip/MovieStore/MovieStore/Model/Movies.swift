//
//  Movies.swift
//  MovieStore
//
//  Created by Brahmastra on 14/01/20.
//  Copyright © 2020 Brahmastra. All rights reserved.
//

import Foundation
import UIKit


struct MoviesModel:Codable {
    var results:[MovieInfo]
}
